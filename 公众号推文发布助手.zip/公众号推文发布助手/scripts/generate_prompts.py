#!/usr/bin/env python3
import re
import sys
from pathlib import Path

if len(sys.argv) < 2:
    print('Usage: generate_prompts.py <article-dir|outline.md>')
    sys.exit(1)

arg = Path(sys.argv[1])
base = arg if arg.is_dir() else arg.parent
outline = base / 'outline.md'
if not outline.exists():
    print(f'Missing outline: {outline}')
    sys.exit(1)

text = outline.read_text(encoding='utf-8', errors='ignore')
blocks = re.split(r'\n(?=## )', text)
prompts_dir = base / 'prompts'
prompts_dir.mkdir(parents=True, exist_ok=True)

mapping = [
    ('01-cover', '封面主视觉，适合作为文章第一屏配图'),
    ('02-conflict', '问题爆发、冲突出现、情绪拉满'),
    ('03-breakdown-1', '第一层拆解，强调结构与分析感'),
    ('04-breakdown-2', '第二层拆解，继续推进逻辑压强'),
    ('05-turning-point', '转折出现，情绪由压转稳'),
    ('06-summary', '总结收口，适合结尾观点页'),
]

for i, block in enumerate([b for b in blocks if b.startswith('## ')][:6]):
    lines = block.splitlines()
    title = lines[0].replace('## ', '').strip()
    core = next((l.split('：',1)[1].strip() for l in lines if l.startswith('- 核心信息：')), '')
    mood = next((l.split('：',1)[1].strip() for l in lines if l.startswith('- 画面情绪：')), '')
    name, goal = mapping[i]
    content = f'''# {title}\n\n主题：{core}\n\n画面目标：\n- {goal}\n\n主体元素：\n- 围绕“{core}”设计清晰主体\n- 有明确前景 / 中景 / 背景层次\n\n视觉风格：\n- cinematic\n- modern editorial\n- high contrast\n- emotionally clear\n\n构图要求：\n- 16:9\n- suitable for article illustration\n- clear focal point\n- visually strong but readable\n\n情绪关键词：\n- {mood}\n\n清晰度要求：\n- 4K\n- high quality\n\n禁用项：\n- watermark\n- blurry details\n- cluttered composition\n- unreadable subject\n'''
    (prompts_dir / f'{name}.md').write_text(content, encoding='utf-8')

print(prompts_dir)
